export const leaderboard = [
    {
        "name": "psyco_bot sdfsdf sf sdf",
        "team_name": "team_psyco",
        "points": 20000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 10000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psycosdfsfsdfsd",
        "points": 9000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 8000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 7000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 6000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 5000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 4000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 3000,
        "profile_image": ""
    },
    {
        "name": "psyco_bot",
        "team_name": "team_psyco",
        "points": 2000,
        "profile_image": ""
    },

]