export const tournaments = [
    {
        "name": "Ten from Cent",
        "start": 1651943861,
        "end": 1651945090,
        "category": "simple",
        "total_spots": 5000,
        "filled_spots": 3000,
        "reward": 1000,
        "entry_price": 250,
        "image": "path",
        "id": 1,
        "live": true,
        "completed": false
    }
    , {
        "name": "Ten from Cent",
        "start": 1651943861,
        "end": 1651945090,
        "category": "simple",
        "total_spots": 5000,
        "filled_spots": 3000,
        "reward": 1000,
        "entry_price": 250,
        "image": "path",
        "id": 2,
        "live": true,
        "completed": false
    }, {
        "name": "Ten from Cent",
        "start": 1651943861,
        "end": 1651945090,
        "category": "simple",
        "total_spots": 5000,
        "filled_spots": 3000,
        "reward": 1000,
        "entry_price": 250,
        "image": "path",
        "id": 3,
        "live": false,
        "completed": true
    }, {
        "name": "Ten from Cent",
        "start": 1651943861,
        "end": 1651945090,
        "category": "simple",
        "total_spots": 5000,
        "filled_spots": 3000,
        "reward": 1000,
        "entry_price": 250,
        "image": "path",
        "id": 4,
        "live": false,
        "completed": false
    }, {
        "name": "Ten from Cent",
        "start": 1651943861,
        "end": 1651945090,
        "category": "simple",
        "total_spots": 5000,
        "filled_spots": 3000,
        "reward": 1000,
        "entry_price": 250,
        "image": "path",
        "id": 5,
        "live": false,
        "completed": false
    }, {
        "name": "Ten from Cent",
        "start": 1651943861,
        "end": 1651945090,
        "category": "simple",
        "total_spots": 5000,
        "filled_spots": 3000,
        "reward": 1000,
        "entry_price": 250,
        "image": "path",
        "id": 6,
        "live": false,
        "completed": false
    }
]