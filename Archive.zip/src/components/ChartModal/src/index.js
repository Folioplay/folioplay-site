import * as React from 'react';

import TickerWidget from '../../TickerWidget/src';


export default function BasicModal() {


  return (
    <div>
      <Button >Open modal</Button>
      <TickerWidget />
    </div>
  );
}