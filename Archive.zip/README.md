# Frontend Repo for folioplay
## Setup
#### Make sure you have nodejs, yarn installed on your system


### Create env at ___./.env___
#### Ask a working developer for env credentials to get started 
### Installation

```bash
yarn
```

### Running the development server

```bash
yarn start
```
##### Development server will run on http://localhost:3000

### Create a production build
```bash
yarn build
```
